sliding-social-icons-slider
===========================

Social icons slider that can be placed on your website or blog to encourage your site visitors to like or follow you on your social media platforms
